let imagens = document.getElementById('img1')
let legendas = document.getElementById('legenda')
function image1()
{
    imagens.src="Berlim/img1.jpg"
    legendas.innerHTML="Vista panorâmica do centro de Berlim."
}
function image2()
{
    imagens.src="Berlim/img2.jpg"
    legendas.innerHTML="Vista noturna da cidade de Berlim."
}
function image3()
{
    imagens.src="Berlim/img3.jpg"
    legendas.innerHTML="Uma foto do marco histórico que é o muro de Berlim."
}
function image4()
{
    imagens.src="Berlim/img4.jpg"
    legendas.innerHTML="Literamente eu montando esse site tendo faltado os dias onde todo o conteúdo foi feito."
}